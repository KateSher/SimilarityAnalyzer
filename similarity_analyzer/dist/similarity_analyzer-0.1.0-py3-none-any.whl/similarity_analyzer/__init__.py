from .text_relevance import RelevantText
